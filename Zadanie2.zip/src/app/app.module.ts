import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Component1Component } from './component1/component1.component';
import { Component2Component } from './component2/component2.component';
import { NavigationComponent } from './navigation/navigation.component';
import { DataListModule } from './data-list/data-list.module';

@NgModule({
  declarations: [
    AppComponent,
    Component1Component,
    Component2Component,
    NavigationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DataListModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
